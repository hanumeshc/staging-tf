#!/bin/bash

gitRepo="https://github.com/OpsMx/predemo-dynamic-accounts.git"
#gitRepo="https://github.com/OpsMx/staging-dynamic-account.git"

baseDir='/tmp'
currDir=`pwd`

gitDir=`basename ${gitRepo%.*}`

#if [ ! -f ~/.git-credentials ]; then
#   echo "Credentials file is not available. Enabling it"
#   git config --global credential.helper store
#else
#   cat ~/.git-credentials | grep -E "OpsMx\:.*\@github\.com"
#   if [ $? -ne 0 ]; then
#      echo "Credential is not present, adding it"
#      git config --global credential.helper store
#   fi
#fi


cd $baseDir
if [ -d $gitDir ]; then
   cd $gitDir
   git pull
   git status
else
#   echo Input the git password for $gitRepo ; read -s pass
   echo $pass | git clone $gitRepo
   cd $gitDir
   git status
fi

acname=$1

echo $acname
cat ./staging/clouddriver-local.yml | grep "name:" | grep ${acname}
if [ $? -eq 0 ]; then
   echo Account already present. No changes done
else
   echo Account not-present, adding to clouddirver ...
   #cp ./staging/clouddriver-ac.tpl clouddriver.tmp
   cp ./clouddriver-ac.tpl clouddriver.tmp
   sed s/\$\{acname\}/$acname/g -i clouddriver.tmp
   #cat clouddriver.tmp >> ./staging/clouddriver-local.yml
   cat clouddriver.tmp >> ./clouddriver-local.yml
   #cp -v $currDir/k8s_${acname}.cfg ./staging/kubecfgsDir/k8s_${acname}.cfg
   cp -v $currDir/k8s_${acname}.cfg ./kubecfgsDir/k8s_${acname}.cfg
   #Add the new account config to git
   #git status
   git config --global user.email "lalit@opsmx.io"
   git config --global user.name lalit 

   rm clouddriver.tmp
   git add .
   git commit -m "Added dynamic account $acname"
   git push
   # git status
fi
